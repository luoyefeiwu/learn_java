create definer = shengyan114@`172.16.148.%` event yh
  on schedule
    every '1' DAY
      starts '2018-06-28 01:00:00'
  enable
do
  BEGIN
     -- 完成
    Update t_banquet Set orderStage=6 Where orderStage in(3,4,5) And orderStatus in (1,2)
                     And date_format(nicheEndTime,'%Y-%m-%d') < date_format(NOW(),'%Y-%m-%d');


    -- 自动丢单
    Update t_banquet Set orderStatus=5 Where orderStage in(1,2,3) And orderStatus =1
                     And date_format(nicheEndTime,'%Y-%m-%d') < date_format(NOW(),'%Y-%m-%d');

    -- 处理“手动丢单”的时间
    update t_banquet set cancelOrderDate = DATE_FORMAT(updateTime,'%Y-%m-%d')
           where orderStatus = 5;


END;

