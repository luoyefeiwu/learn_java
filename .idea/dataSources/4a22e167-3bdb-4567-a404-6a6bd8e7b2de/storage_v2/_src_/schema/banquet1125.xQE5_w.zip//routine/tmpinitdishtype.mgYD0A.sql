create procedure tmpInitDishType()
  BEGIN
	 -- 循环写入餐厅的菜品类别
                declare varRestaurantID varchar(36);
                declare flag int default 0;

                declare iCur cursor for Select DISTINCT restaurantId from t_sys_department;

                declare continue handler for not found set flag = 1;
                open iCur;
                repeat
                      fetch iCur into varRestaurantID;
                      if not flag THEN
                         Insert into t_sys_DishType(TypeID,Sequence,TypeName,RestaurantID,CreateDate) VALUES(UUID(),1,'凉菜',varRestaurantID,NOW());
                         Insert into t_sys_DishType(TypeID,Sequence,TypeName,RestaurantID,CreateDate) VALUES(UUID(),2,'热菜',varRestaurantID,NOW());
                         Insert into t_sys_DishType(TypeID,Sequence,TypeName,RestaurantID,CreateDate) VALUES(UUID(),3,'主食',varRestaurantID,NOW());
                         Insert into t_sys_DishType(TypeID,Sequence,TypeName,RestaurantID,CreateDate) VALUES(UUID(),4,'汤羹',varRestaurantID,NOW());
                         Insert into t_sys_DishType(TypeID,Sequence,TypeName,RestaurantID,CreateDate) VALUES(UUID(),5,'赠送',varRestaurantID,NOW());
                      end if;

                until flag end repeat;
                close iCur;

END;

