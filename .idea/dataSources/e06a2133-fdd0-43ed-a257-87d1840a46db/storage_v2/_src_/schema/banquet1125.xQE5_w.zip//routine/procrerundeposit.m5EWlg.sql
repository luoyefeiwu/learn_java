create procedure procRerunDeposit()
  BEGIN 
	  DECLARE dayIndex INT DEFAULT 1;
    DECLARE reportDay varchar(20);
  
    WHILE dayIndex <=5 DO
        
        SET reportDay = CONCAT('2020-01-01', dayIndex);
 
        call procDepositReport(reportDay);

        SET dayIndex = dayIndex + 1;
 
    END WHILE;
 
    SELECT "Success";
END;

