create procedure procDepositReport(IN `_inDay` date)
  BEGIN

SET @reportDay =  DATE_FORMAT(_inDay,'%Y-%m-%d');
SET @lastDay = DATE_FORMAT(DATE_SUB(_inDay,interval 1 day),'%Y-%m-%d');

-- 清除报表日的数据
Delete from t_deposit_report Where reportDay = @reportDay;

-- 写入报表日的数据
Insert into t_deposit_report(restaurantId,reportDay,createTime,reportId)
select Distinct restaurantId,@reportDay as reportDay ,NOW() as createTime,UUID() AS reportId from t_sys_department;

-- 修改报表日的收入金额
Update t_deposit_report r
INNER JOIN (Select restaurantId,sum(amount) as amountIn  from t_banquet_deposit_details
       Where financeConfirmed=1 And DATE_FORMAT(payTime,'%Y-%m-%d') = @reportDay GROUP BY restaurantId) d
ON r.restaurantId = d.restaurantId
SET r.amountIn = d.amountIn
Where r.reportDay = @reportDay;

-- 修改报表日的退出金额
Update t_deposit_report r
INNER JOIN (Select restaurantId,sum(amount_Out) as amountOut  from t_banquet_deposit_refund
       Where DATE_FORMAT(refundTime,'%Y-%m-%d') = @reportDay GROUP BY restaurantId) d
ON r.restaurantId = d.restaurantId
SET r.amountOut = d.amountOut
Where r.reportDay = @reportDay;

-- 修改报表日的结存金额
Update t_deposit_report Set amountLeft = amountIn - amountOut
       Where reportDay = @reportDay;

Update t_deposit_report r
INNER JOIN (Select restaurantId,amountLeft from t_deposit_report
      Where reportDay = @lastDay ) d
ON r.restaurantId = d.restaurantId
SET r.amountLeft = d.amountLeft + r.amountIn - r.amountOut
Where r.reportDay = @reportDay;


END;

