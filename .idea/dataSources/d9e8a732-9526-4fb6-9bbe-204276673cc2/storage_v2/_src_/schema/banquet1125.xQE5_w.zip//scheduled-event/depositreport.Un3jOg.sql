create definer = shengyan114@`172.16.148.%` event depositReport
  on schedule
    every '1' DAY
      starts '2018-10-22 00:10:00'
  enable
do
  BEGIN
  /*********  本脚本的运行时间必须为凌晨后开始，运算昨天的数据  *********/
  SET @reportDay = DATE_SUB(NOW(),interval 1 day);
  call procDepositReport(@reportDay);
END;

